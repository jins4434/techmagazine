<!DOCTYPE html>
<html>
<head>
<script>
function validateForm() 
{
   if (document.techmag.abc.value == "") {
        alert("please Enter a name");
        document.techmag.abc.focus();
        return false;
    }
    if (!/^[a-zA-Z]*$/g.test(document.techmag.abc.value)) {
        alert(" sorry Invalid characters/enter only ur name/avoid spaces between words");
        document.techmag.abc.focus();
        return false;
    }
	


    if (document.techmag.gml.value == "") {
        alert("please Enter your email");
        document.techmag.gml.focus();
        return false;
    }
    if (! /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(document.techmag.gml.value)) {
        alert(" sorry Invalid email format");
        document.techmag.gml.focus();
        return false;
    }

       if (document.techmag.phn.value == "") {
        alert("please Enter your contact no");
        document.techmag.phn.focus();
        return false;
    }
    if (!/^[0-9]+$/.test(document.techmag.phn.value)) {
        alert(" sorry all input should be numeric");
        document.techmag.phn.focus();
        return false;
    }
     if (document.techmag.hij.value == "") {
        alert("please Entername of subject for row 1 no");
        document.techmag.hij.focus();
        return false;
    }
    if (!/^[a-zA-Z]*$/g.test(document.techmag.hij.value)) {
        alert(" sorry all input should be characters");
        document.techmag.hij.focus();
        return false;
    }
   
	if (document.techmag.klm.value == "") {
        alert("please Enter your marks for row 1");
        document.techmag.klm.focus();
        return false;
    }
    if (!/^[0-9]+$/.test(document.techmag.klm.value)) {
        alert(" sorry all input should be numeric");
        document.techmag.klm.focus();
        return false;
    } 
	
	
	
	var r = document.forms["techmag"]["nop"].value;
    if (r == "") {
        alert("upload a jpg format photo for row 1");
        return false;
    }


 if (document.techmag.qrs.value == "") {
        alert("please Enter your subject for row2");
        document.techmag.qrs.focus();
        return false;
    }
    if (!/^[a-zA-Z]*$/g.test(document.techmag.qrs.value)) {
        alert(" sorry all input should be characters");
        document.techmag.qrs.focus();
        return false;
    }
    if (document.techmag.tuv.value == "") {
        alert("please Enter your marks for row 2");
        document.techmag.tuv.focus();
        return false;
    }
    if (!/^[0-9]+$/.test(document.techmag.tuv.value)) {
        alert(" sorry all input should be numeric");
        document.techmag.tuv.focus();
        return false;
    } 
    


    var c = document.forms["techmag"]["wxy"].value;
    if (c == "") {
        alert("upload a jpg format photo for row 2");
        return false;
    }
	 if (document.techmag.jin.value == "") {
        alert("please Enter your subject for row3");
        document.techmag.jin.focus();
        return false;
    }
    if (!/^[a-zA-Z]*$/g.test(document.techmag.jin.value)) {
        alert(" sorry all input should be characters");
        document.techmag.jin.focus();
        return false;
    }
    if (document.techmag.sni.value == "") {
        alert("please Enter your marks for row 3");
        document.techmag.sni.focus();
        return false;
    }
    if (!/^[0-9]+$/.test(document.techmag.sni.value)) {
        alert(" sorry all input should be numeric");
        document.techmag.sni.focus();
        return false;
    } 

    var j= document.forms["techmag"]["jes"].value;
    if (j == "") {
        alert("upload a jpg format photo for row 3");
        return false;
	}
	if (document.techmag.nij.value == "") {
        alert("please Enter tite of paper for row1");
        document.techmag.nij.focus();
        return false;
    }
    if (!/^[a-zA-Z]*$/g.test(document.techmag.nij.value)) {
        alert(" sorry all input should be characters");
        document.techmag.nij.focus();
        return false;
    }
if (document.techmag.ins.value == "") {
        alert("please Enter name of conference for row1");
        document.techmag.ins.focus();
        return false;
    }
    if (!/^[a-zA-Z]*$/g.test(document.techmag.ins.value)) {
        alert(" sorry all input should be characters");
        document.techmag.ins.focus();
        return false;
    }
	if (document.techmag.sej.value == "") {
        alert("please Enter student acheivement for row1");
        document.techmag.sej.focus();
        return false;
    }
    if (!/^[a-zA-Z]*$/g.test(document.techmag.sej.value)) {
        alert(" sorry all input should be characters");
        document.techmag.sej.focus();
        return false;
    }
	if (document.techmag.aij.value == "") {
        alert("please Enter student initiative for row1");
        document.techmag.aij.focus();
        return false;
    }
    if (!/^[a-zA-Z]*$/g.test(document.techmag.aij.value)) {
        alert(" sorry all input should be characters");
        document.techmag.aij.focus();
        return false;
    }
if (document.techmag.bin.value == "") {
        alert("please Enter tite of paper for row2");
        document.techmag.bin.focus();
        return false;
    }
    if (!/^[a-zA-Z]*$/g.test(document.techmag.bin.value)) {
        alert(" sorry all input should be characters");
        document.techmag.bin.focus();
        return false;
    }
if (document.techmag.mee.value == "") {
        alert("please Enter name of conference for row2");
        document.techmag.mee.focus();
        return false;
    }
    if (!/^[a-zA-Z]*$/g.test(document.techmag.mee.value)) {
        alert(" sorry all input should be characters");
        document.techmag.mee.focus();
        return false;
    }
	if (document.techmag.swa.value == "") {
        alert("please Enter student acheivement for row2");
        document.techmag.swa.focus();
        return false;
    }
    if (!/^[a-zA-Z]*$/g.test(document.techmag.swa.value)) {
        alert(" sorry all input should be characters");
        document.techmag.swa.focus();
        return false;
    }
	if (document.techmag.nav.value == "") {
        alert("please Enter student initiative for row2");
        document.techmag.nav.focus();
        return false;
    }
    if (!/^[a-zA-Z]*$/g.test(document.techmag.nav.value)) {
        alert(" sorry all input should be characters");
        document.techmag.nav.focus();
        return false;
    }
if (document.techmag.nee.value == "") {
        alert("please Enter tite of paper for row3");
        document.techmag.nee.focus();
        return false;
    }
    if (!/^[a-zA-Z]*$/g.test(document.techmag.nee.value)) {
        alert(" sorry all input should be characters");
        document.techmag.nee.focus();
        return false;
    }
if (document.techmag.naa.value == "") {
        alert("please Enter name of conference for row3");
        document.techmag.naa.focus();
        return false;
    }
    if (!/^[a-zA-Z]*$/g.test(document.techmag.naa.value)) {
        alert(" sorry all input should be characters");
        document.techmag.naa.focus();
        return false;
    }
	if (document.techmag.vis.value == "") {
        alert("please Enter student acheivement for row3");
        document.techmag.vis.focus();
        return false;
    }
    if (!/^[a-zA-Z]*$/g.test(document.techmag.vis.value)) {
        alert(" sorry all input should be characters");
        document.techmag.vis.focus();
        return false;
    }
	if (document.techmag.khr.value == "") {
        alert("please Enter student initiative for row3");
        document.techmag.khr.focus();
        return false;
    }
    if (!/^[a-zA-Z]*$/g.test(document.techmag.khr.value)) {
        alert(" sorry all input should be characters");
        document.techmag.khr.focus();
        return false;
    }
	
	
	
	if (document.techmag.sum.value == "") {
        alert("please Enter tite of paper for row3");
        document.techmag.sum.focus();
        return false;
    }
    if (!/^[a-zA-Z]*$/g.test(document.techmag.sum.value)) {
        alert(" sorry all input should be characters");
        document.techmag.sum.focus();
        return false;
    }
if (document.techmag.ros.value == "") {
        alert("please Enter name of conference for row3");
        document.techmag.ros.focus();
        return false;
    }
    if (!/^[a-zA-Z]*$/g.test(document.techmag.ros.value)) {
        alert(" sorry all input should be characters");
        document.techmag.ros.focus();
        return false;
    }
	if (document.techmag.jos.value == "") {
        alert("please Enter student acheivement for row3");
        document.techmag.jos.focus();
        return false;
    }
    if (!/^[a-zA-Z]*$/g.test(document.techmag.jos.value)) {
        alert(" sorry all input should be characters");
        document.techmag.jos.focus();
        return false;
    }
	if (document.techmag.jus.value == "") {
        alert("please Enter student initiative for row3");
        document.techmag.jus.focus();
        return false;
    }
    if (!/^[a-zA-Z]*$/g.test(document.techmag.jus.value)) {
        alert(" sorry all input should be characters");
        document.techmag.jus.focus();
        return false;
    }
	
	if (document.techmag.rav.value == "") {
        alert("please Enter sr no for row 1");
        document.techmag.rav.focus();
        return false;
    }
    if (!/^[0-9]+$/.test(document.techmag.rav.value)) {
        alert(" sorry all input should be numeric");
        document.techmag.rav.focus();
        return false;
    } 
    

    var yog = document.forms["techmag"]["sri"].value;
    if (yog == "") {
        alert(" upload jpg photo for row 1");
        return false;
    }


    if (document.techmag.kan.value == "") {
        alert("please Enter sr no for row 2");
        document.techmag.kan.focus();
        return false;
    }
    if (!/^[0-9]+$/.test(document.techmag.kan.value)) {
        alert(" sorry all input should be numeric");
        document.techmag.kan.focus();
        return false;
    } 
	var nox= document.forms["techmag"]["sree"].value;
    if (nox == "") {
        alert("upload jpg photo for row2 ");
        return false;
    }

    

    if (document.techmag.jiv.value == "") {
        alert("please Enter sr no for row 3");
        document.techmag.jiv.focus();
        return false;
    }
    if (!/^[0-9]+$/.test(document.techmag.jiv.value)) {
        alert(" sorry all input should be numeric");
        document.techmag.jiv.focus();
        return false;
    } 
	 var yuk = document.forms["techmag"]["vij"].value;
    if (yuk == "") {
        alert("upload jpg photo for row 3" );
        return false;
    }
if (document.techmag.aus.value == "") {
        alert("please Enter name of the contest  for row1");
        document.techmag.aus.focus();
        return false;
    }
    if (!/^[a-zA-Z]*$/g.test(document.techmag.aus.value)) {
        alert(" sorry all input should be characters");
        document.techmag.aus.focus();
        return false;
    }
    if (document.techmag.bus.value == "") {
        alert("please Enter rank for row 1");
        document.techmag.bus.focus();
        return false;
    }
    if (!/^[0-9]+$/.test(document.techmag.bus.value)) {
        alert(" sorry all input should be numeric");
        document.techmag.bus.focus();
        return false;
    } 


    if (document.techmag.cus.value == "") {
        alert("please Enter name of the student  for row1");
        document.techmag.cus.focus();
    }    return false;
    
    if (!/^[a-zA-Z]*$/g.test(document.techmag.cus.value)) {
        alert(" sorry all input should be characters");
        document.techmag.cus.focus();
        return false;
    }
	if (document.techmag.dus.value == "") {
        alert("please Enter name of the contest  for row2");
        document.techmag.dus.focus();
        return false;
    }
    if (!/^[a-zA-Z]*$/g.test(document.techmag.dus.value)) {
        alert(" sorry all input should be characters");
        document.techmag.dus.focus();
        return false;
    }
    if (document.techmag.eus.value == "") {
        alert("please Enter rank for row 2");
        document.techmag.eus.focus();
        return false;
    }
    if (!/^[0-9]+$/.test(document.techmag.eus.value)) {
        alert(" sorry all input should be numeric");
        document.techmag.eus.focus();
        return false;
    } 


    if (document.techmag.fus.value == "") {
        alert("please Enter name of the student  for row2");
        document.techmag.fus.focus();
        return false;
    }
    if (!/^[a-zA-Z]*$/g.test(document.techmag.fus.value)) {
        alert(" sorry all input should be characters");
        document.techmag.fus.focus();
        return false;
    }
if (document.techmag.gus.value == "") {
        alert("please Enter name of the contest  for row3");
        document.techmag.gus.focus();
        return false;
    }
    if (!/^[a-zA-Z]*$/g.test(document.techmag.gus.value)) {
        alert(" sorry all input should be characters");
        document.techmag.gus.focus();
        return false;
    }
    if (document.techmag.hus.value == "") {
        alert("please Enter rank for row 3");
        document.techmag.hus.focus();
        return false;
    }
    if (!/^[0-9]+$/.test(document.techmag.hus.value)) {
        alert(" sorry all input should be numeric");
        document.techmag.hus.focus();
        return false;
    } 


    if (document.techmag.ius.value == "") {
        alert("please Enter name of the student  for row3");
        document.techmag.ius.focus();
        return false;
    }
    if (!/^[a-zA-Z]*$/g.test(document.techmag.ius.value)) {
        alert(" sorry all input should be characters");
        document.techmag.ius.focus();
        return false;
    }
 
}

</script>
</head>
<body>
<style>
body {
    background-color: orange;
}

h1 {
    color: white;
    text-align: center;
}

p {
    font-family: verdana;
    font-size: 20px;
}
input[type=email], select {
    width: 100%;
    padding: 12px 20px;
    margin: 8px 0;
    display: inline-block;
    border: 1px solid #ccc;
    border-radius: 4px;
    box-sizing: border-box;
}
input[type=text], select {
    width: 100%;
    padding: 12px 20px;
    margin: 8px 0;
    display: inline-block;
    border: 1px solid #ccc;
    border-radius: 4px;
    box-sizing: border-box;
}

input[type=submit] {
    width: 100%;
    background-color: red;
    color: white;
    padding: 14px 20px;
    margin: 8px 0;
    border: none;
    border-radius: 4px;
    cursor: pointer;
}



div {
    border-radius: 5px;
    background-color: #f2f2f2;
    padding: 20px;
}
</style>
<h1><center>Don Bosco Institute Of Technology</center></h1>
<h2><center>TECH MAGAZINE 2016-2017</center></h2>

 <fieldset>
 <form name = "techmag"
 action=""
onsubmit="return validateForm()"
 method ="post">
<legend>PERSONAL INFORMATION:</legend>
NAME:<input type ="text" name = "name" id = "123" onkeyup= "limit(this,5);" onkeydown="limit(this)"><br>
EMAIL:<input type ="email" name = "email" id = "456"><br>
PHONE NO:<input type ="text" name= "phone" id ="789"onkeyup="limit(this,10);"><br>
DEPARTMENT
<select name = "department">
<option value ="MECH">MECH</option>
<option value ="EXTC">EXTC</option>
<option value ="I.T">I.T</option>
<option value ="COMPS">COMPS</option>
</select><br>
YEAR
<select name = "year">
<option value ="F.E">F.E</option>
<option value ="S.E">S.E</option>
<option value ="T.E">T.E</option>
<option value ="B.E">B.E</option>
</select><br>
<input name="submit" type="submit" value="Submit">

<input name="display" type="submit" value="Display">
</form>
<?php
if(isset($_POST['submit']))
{
	include "connect.php";
$name=$_POST['name'];
$email=$_POST['email'];
$phone=$_POST['phone'];
$department=$_POST['department'];
$year=$_POST['year'];

mysql_query("insert into personalinfo values('$name','$email','$phone','$department','$year')");
}
if(isset($_POST['display']))
{
	echo "<table>";
	include "connect.php";

$p=mysql_query("select * from personalinfo");
$row=mysql_num_rows($p);
if ($row > 0) {
    // output data of each row
		
	   echo "<tr><th>Name</th><th>Email</th><th>Phone</th><th>Department</th><th>Year</th></tr>";
    while($row =  mysql_fetch_assoc($p)) {
        echo "<tr><td>" . $row["name"]."</td><td>" . $row["email"]."</td><td>".$row["phone"]."</td><td>".$row["department"]."</td><td>".$row["year"]."</td></tr>";
    }

} else {
    echo "0 results";
}
echo "</table>";
}
?>
</fieldset>
</body>
</html>
